@extends('layouts.app')

@section('content')
<h2 style="text-align: center;"><b>Edit Profile </b> </h2><br>

<div class="card-body">
    <form action="{{ route('user.update',$user->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="row mb-3">
            <label for="name" class="col-md-4 col-form-label text-md-end">{{ __('Name') }}</label>

            <div class="col-md-6">
                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ $user->name }}" required autocomplete="name" autofocus>

                @error('name')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

            <div class="col-md-6">
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $user->email }}" required autocomplete="email">

                @error('email')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="image" class="col-md-4 col-form-label text-md-end">{{ __('image') }}</label>

            <div class="col-md-6">
                <input id="image" type="file" class="form-control @error('image') is-invalid @enderror" name="image" required>
                @error('email')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="gender" class="col-md-4 col-form-label text-md-end">{{ __('gender') }}</label>

            <div class="col-md-6">
                <input id="gender" type="radio" value="male" name="gender">Male
                <input id="gender" type="radio" value="female" name="gender">Female

                @error('gender')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="age" class="col-md-4 col-form-label text-md-end">{{ __('Age') }}</label>

            <div class="col-md-6">
                <select name="age" class="form-control">
                    <option value="">Select</option>
                    <option value=" 18-30"> 18-30</option>
                    <option value=" 31-40"> 31-40</option>
                    <option value=" Above-40"> Above-40</option>
                </select>

                @error('gender')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="services" class="col-md-4 col-form-label text-md-end">{{ __('Services') }}</label>

            <div class="col-md-6">
                @foreach($works as $work)
                <input type="checkbox" id="services" name="services[]" value="{{$work->id}}">{{$work->work_name}}<br />
                
                @endforeach
                @error('gender')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
        </div>

        <div class="row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary">
                    {{ __('update') }}
                </button>
            </div>
        </div>
    </form>
</div>
<script>
    $(document).ready(function() {
        $("#regForm").validate({
            rules: {
                name: {
                    required: true,
                    maxlength: 20,
                },

                email: {
                    required: true,
                    email: true,
                },

                password: {
                    required: true,
                    minlength: 6,
                    maxlength: 10,
                },
                confirmPassword: {
                    required: true,
                    equalTo: "#password"
                },
                status: {
                    required: true,
                },

            },
            messages: {
                name: {
                    required: "First name is required",
                    maxlength: "First name cannot be more than 20 characters"
                },
                email: {
                    required: "Email is required",
                    email: "Email must be a valid email address",
                    maxlength: "Email cannot be more than 50 characters",
                },

                password: {
                    required: "Password is required",
                    minlength: "Password must be at least 5 characters"
                },
                confirmPassword: {
                    required: "Confirm password is required",
                    equalTo: "Password and confirm password should same"
                },
                status: {
                    required: "Please select the gender",
                },


            }
        });
    });
</script>
@endsection