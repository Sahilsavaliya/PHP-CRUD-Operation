
<?php $__env->startSection('content'); ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>



<div class="container">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right">


                <h2 style="text-align: center;"><b> Admin List </b> </h2><br>

            </div>


            <a class="btn btn-success" href="<?php echo e(route('user.create')); ?>"> Create New User</a>





        </div>
    </div>
    <br>

    <div id="msg">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
    </div>
    <br>

    <br><br>
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Email</th>
            <th>image</th>
            <th>gender</th>
            <th>Age</th>
            <th>Services</th>
            <th width="200px">Action</th>

        </tr>
        <tbody id="tbody">
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($user1->name); ?></td>
            <td><?php echo e($user1->email); ?></td>
            <td><?php echo e($user1->image); ?></td>
            <td><?php echo e($user1->gender); ?></td>
            <td><?php echo e($user1->age); ?></td>
            <td><?php echo e($user1->services); ?></td>

            <td>
                <form action="<?php echo e(route('user.update_aprove',$user1->id)); ?>" method="POST">
                    <div class="col-md-6">
                        <input id="status" type="radio" value="active" name="status" checked hidden>

                    </div>
                    <?php echo csrf_field(); ?>
                    <button type="submit">Aprove</button>
                </form>
            </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\family_management\resources\views/user/show.blade.php ENDPATH**/ ?>