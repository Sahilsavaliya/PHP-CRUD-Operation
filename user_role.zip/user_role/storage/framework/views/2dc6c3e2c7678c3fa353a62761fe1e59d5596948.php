
<?php $__env->startSection('content'); ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<div class="container">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right">
                <h2 style="text-align: center;"><b> Modules List </b> </h2><br>
            </div>
           
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('module.create')); ?>"> Create New module</a>
               
                <a class="btn btn-success" href="<?php echo e(route('user.index')); ?>"> Home </a>

               

            </div>
        </div>



        <div id="msg">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
        </div>

        <br><br>
        <table class="table table-bordered">
            <tr>
                <th>No</th>
                <th>Name</th>
                
                <th width="200px">Action</th>
            </tr>
            <tbody id="tbody">
                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($module->modules_name); ?></td>
                    
                    <td>    
                        <form action="<?php echo e(route('module.destroy',$module->id)); ?>" method="POST">
                            <a class="btn btn-primary" href="<?php echo e(route('module.edit',$module->id)); ?>">Edit</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger delete">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    
    <?php echo $modules->links(); ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\user_role\resources\views/module/index.blade.php ENDPATH**/ ?>