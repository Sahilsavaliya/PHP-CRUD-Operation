
<?php $__env->startSection('content'); ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<div class="container">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right">
                
           
                <h2 style="text-align: center;"><b> Admin List </b> </h2><br>
                
            </div>
           
            <div class="pull-right">
            <?php if(Auth::user()->roles_id == 1||Auth::user()->roles_id == 3||Auth::user()->roles_id == 4): ?>
                <a class="btn btn-success" href="<?php echo e(route('user.create')); ?>"> Create New User</a>
                <a class="btn btn-success" href="<?php echo e(route('excel')); ?>"> Export Excel File</a>
                <?php endif; ?>
                <?php if(Auth::user()->roles_id == 2||Auth::user()->roles_id == 5||Auth::user()->roles_id == 6): ?>
                <a class="btn btn-success" href="<?php echo e(route('role.index')); ?>"> Roles</a>
                <?php endif; ?>
                <?php if(Auth::user()->roles_id == 1): ?>
                <a class="btn btn-success" href="<?php echo e(route('module.index')); ?>"> Module</a>
                <?php endif; ?>
            </div>
        </div>



        <div id="msg">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
        </div>

        <br><br>
        <table class="table table-bordered">
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role_name</th>
                <?php if(Auth::user()->roles_id == 3||Auth::user()->roles_id == 4): ?>{
                <th width="200px">Action</th>
                }
                <?php endif; ?>              
            </tr>
            <tbody id="tbody">
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user1->id); ?></td>
                    <td><?php echo e($user1->name); ?></td>
                    <td><?php echo e($user1->email); ?></td>
                   
                    <td><?php echo e(!empty($user1->roles)?$user1->roles->roles_name:''); ?></td>
                   
                    <td>    
                        <form action="<?php echo e(route('user.destroy',$user1->id)); ?>" method="POST">
                        <?php if(Auth::user()->roles_id == 3): ?>{
                            <a class="btn btn-primary" href="<?php echo e(route('user.edit',$user1->id)); ?>">Edit</a>
                        }<?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <?php if(Auth::user()->roles_id == 4): ?>{
                            <button type="submit" class="btn btn-danger delete">Delete</button>
                        }<?php endif; ?>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    
  

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\user_role\resources\views/user/index.blade.php ENDPATH**/ ?>